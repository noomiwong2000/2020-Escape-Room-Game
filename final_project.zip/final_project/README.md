This is an interactive story game. Before playing it, make sure arcade is installed. You can do this by entering 'pip3 install arcade' on the command line. My program runs on the file main.py and you should open that file and run it. You don't need to open any of the other files to play the game, they are simply used to assist in the creation of my game.

To move through the game, simply click on the window (the area where the game is displayed). Sometimes you will have to make a choice to continue the story. In that case, follow the instructions displayed on the screen to choose. They will prompt you to either press the up or down arrow key. 

This story game is somewhat of a documentation to what is going on in our world right now. With the coronavirus pandemic, police brutality, riots etc. I thought it seemed like Pandora's box opening all over again. However, there is still so much hope for the future. With that said, I hope you enjoy the game. 

