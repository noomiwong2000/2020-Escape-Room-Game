# Script for the story.
text = dict()
text['instructions'] = "This is an interactive game.\nTo move through the game, simply click on the window. Sometimes you will be\nprompted to make a choice. When this happens, simply follow the instructions and press\nthe up or down arrow to make your choice."

text['scene0'] = "It’s 2068 and you're in the most prestigious museum\nin the country. A hallway marked ‘Restricted Area’ catches\nyour eye and you find yourself being drawn into it. There’s\none door in this section and you cautiously open and step inside it.\nSuddenly, the door slams and you hear the click of a lock behind you.\nDarkness encompasses you."

text['scene1'] = "Panic sets in and just before you let out a scream for someone to\nlet you out, a fluorescent blue light appears. A voice\nin your head tells you that you’re stuck, for now at least. "

text['scene2'] = "There’s a box behind you. Open it and you might find some clues."

text['scene3'] = "You lift the lid apprehensively and swirls of dark mist escapes.\nLooking inside, you are disappointed to find nothing.\nYou close the lid. Something in the room feels different\nsomehow. Why don’t you check the portal?"

text['scene4'] = "Seems like the portal is open now. Don’t be afraid.\nYou have nowhere else to go anyways."

text['scene5'] = "You step out of the light and into the front of a convenient store.\nWhy are you here again? Oh, that’s right. Your girlfriend\nwanted you to get some snacks for movie night."

text['scene6'] = "Minding your own business, you miss the anxious\nglances the cashier is giving you. You walk to the drink aisle.\nSoda or water?"

text['scene7'] = "Soda it is. You know it's your girlfriend's go to."

text['scene8'] = "Water it is. You know your girlfriend hates sugary drinks."

text['scene9'] = "You hear a familiar siren and you glance up to see\ntwo cops enter, guns pointing straight at you."

text['scene10'] = "You lift your sweaty hands high above your head. Maybe you forgot\nto return a library book when you were younger but, besides that,\nyou can’t think of one thing you did wrong. Should you stand\nup for yourself?"

text['scene11'] = "You push the officer away. This isn’t fair treatment. He retaliates\nand kicks you in the head. The world spins and you fall to the floor,\nblood dripping everywhere. The officer laughs."

text['scene12'] = "You slowly get on your knees, complying with the officer’s orders.\n“Please don’t hurt me. I’m innocent.” He shoves you to the ground,\n“I’m just doing my job.” A sharp, metallic taste fills your mouth. Suddenly, you\nfeel a force at the back of your head. You black out."

text['scene13'] = "That could have gone better. Why don’t you try again?\nMaybe this time you’ll find a way to escape this place. "

text['scene14'] = "You step into the portal again. This time, you’re wearing a\ntight blue uniform with a gun strapped to your side. Your partner\nhad gotten a call about a theft at a drugstore. You sigh, hopefully\nthis situation gets settled quickly."

text['scene15'] = "You and your partner enter the store. You don't immediately\nsee the trouble but your partner pulls his gun out.\nYou follow suit. "

text['scene16'] = "The dispatcher mentioned that the suspect is a tall African American\nman and there is only one in this store. Your partner takes\ninitiative and begins to order the man to put his hands up.\nThen, the suspect is forced out of the store with a gun trained to his head.\nYour partner seems to be acting especially rough with this one."

text['scene17'] = "The suspect is clearly terrified and pleading that he is innocent.\nYour partner doesn’t listen and shoves him to the ground.\nYou know this is wrong, your partner shouldn’t be using\nthis much force. Will you intervene?"

text['scene19'] = "You stand idly by. Worried that you may compromise your relationship\nwith your partner later. Suddenly, your partner kicks the suspect\nin the head with substantial force. Unable to help yourself,\nyou let out a yell. You know your partner just crossed the line.\nSome noise erupts in the distance and you squint your eyes\nto see a group of rioters approaching."

text['scene20'] = "A car is set ablaze and a group of them cheers.\nYou urge your partner to stop but he still doesn't listen.\nYour yelling catches the attention of one of the rioters and\nhe glances at the suspect on his knees crying for mercy. He yells,\n“DEATH TO OPS!” You turn to raise your gun but the rioter beats you\nto it. The bullet rips through your uniform and you slowly bleed out."

text['scene18'] = "You tell your partner to take it easy. He still doesn’t budge.\nYou push your partner off the man. You search\nthe man and find he has not stolen anything."

text['scene21'] = "Well done. You made it back alive this time.\nCheck the box. Maybe your efforts have been rewarded."

text['scene22'] = "Guess not. Shall we try one more time?"

text['scene23'] = "You step through the portal once more."

text['scene24'] = "The light is blinding as you wipe your tired eyes.\nBusiness has been slow today in the drug store but\nyou think it’s for the best. From the people carrying the\nvirus to the looters, you can’t trust anyone these days. Life\nas we knew it seemed to be falling apart by the hour."

text['scene25'] = "Just then, the door rings and an African American man walks in.\nYou keep a wary eye on him as something about him keeps you on your toes.\nHe is dressed in all black and is taking too long in deciding what he wants\nto buy. You remember your wife was robbed a week ago and you pick up\nthe phone to call 911. "

text['scene26'] = "Your call is interrupted by a customer and you quickly put\nthe phone down. Items are quickly scanned and you send the customer on his way.\nJust before you pick up the phone again, laughter erupts from one of the aisles.\nThe sound came from the man and you realize he’s talking to...his girlfriend. Something\ntells you to put the phone down. There’s no need to make that call. "

text['scene27'] = "You’re pulled out of the store and find yourself in the dark room\nonce more. Interesting. I have a feeling something’s different this\ntime. Check the box again, why don’t you?"

text['scene28'] = "You look in the box and find a note.\n 'HOPE' it reads. Beneath it lays the key."

text['scene29'] = "Ah, there’s that elusive key. Congratulations. It’s been fun.\nThanks for stopping by to see the 2020 exhibit. Enjoy the rest\nof your experience here at the Museum of Times."

text['scene30'] = "Click to restart."
