Python as it is does not traditionally work with dispaying images to the user. Most of the time the user inputs some text or value, and the program outputs some other text. I knew I wanted to make a visual game, and using arcade helped me do that. 

Arcade is a library (like a resource) that helps programmers to easily create games with graphics and sounds. To be able to use the tools that Arcade provides, you first have to download it. Simply enter 'pip3 install arcade' on the command line of the terminal window. In the following sections I will explain how I created an example scene of my game using Arcade. 

1. If you want to use Arcade, the first line of code should always be 'import arcade'. This lets you use the tools/code provided in Arcade. 

2. My program uses lots of images. In order for your computer to find and reference those images easily, you should include these three lines of code:

import os 
file_path = os.path.dirname(os.path.abspath(__file__))
os.chdir(file_path)

3. To display anything to the user, we need this line of code:

arcade.start_render()

Esentially, it tells the computer to start "drawing" elements on the screen. 

4. Next we tell the computer what to draw. For me, I needed to display a background image in each scene. You can do this by first loading the image on to your program by referencing arcade's code and then drawing a rectangle in the shape of your image.

background = arcade.load_texture(image)
arcade.draw_lrwh_rectangle_textured(bottom_left_x, bottom_left_y, screen_width, screen_height, background)

When you load the image, put the image file name in quotes in the parenthesis. In the next line, fill in the values you want in the parenthesis. bottom_left_x and bottom_left_y is where you want the image to start drawing on the window. Arcade uses a traditional coordinate system, so the point (0,0) represents the bottom left hand corner of your window. Screen_width and screen_height just represents the size of your image. Finally, background will just reference the image you loaded. 

5. To display text, simply use this line of code and change the values in the parenthesis. 

arcade.draw_text("Put text here", x_coordinate, y_coordinate, 
                        arcade.color.WHITE, font_size=12)

What you're doing is referencing arcade's tools to help you display text. Put the text you want to display in quotes, followed by the x and y coordinate of where you want to display the text. You can also desginate the font color and the font size you want by changing those values. 

6. Then to display it all, you have to tell the computer to run the program. Otherwise, nothing gets displayed to the user. Use this line of code:

arcade.run()

That's pretty much the basics of using Arcade. If you have anything that runs on the regular terminal window, those lines of code will be executed first before anything is displayed using arcade. 

Arcade is meant to have interactions only happen with your game, so I couldn't have my user type in 'continue' or ask them to type in their choice in the terminal window. However, arcade makes my game more user friendly by having them just click on the screen to continue. The only thing that aracde recognizes when it comes to user inputs are mouse clicks, or specific keys such as the up or down arrow. Using this, I was able to switch scenes by recognizing when the mouse was clicked and have the user make decisions by pressing the up or down arrow key. 

I switched scenes by modifying arcade's built in tool/function that normally checks to see if the mouse was pressed. When the mouse was pressed, I changed the code to display my next scene. I also modified the tool/function that checks if the up or down arrow key was pressed to display the appropriate scene depedning on what was chosen by the user. 
