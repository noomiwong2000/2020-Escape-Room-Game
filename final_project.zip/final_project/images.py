# Images for the story.

""" Images from:
https://www.drweil.com/health-wellness/body-mind-spirit/vision/can-watching-tv-in-the-dark-hurt-your-eyes/
https://www.shutterstock.com/search/spotlight+in+dark+room
https://wisedime.com/why-you-should-be-shopping-for-groceries-at-night/
https://www.youtube.com/watch?v=IoDn9P7b8WY
https://www.youtube.com/watch?v=9Elem7z8yVw
https://www.pinterest.com/startrekmulti/gun-aesthetic/
https://staringatjacob.nl/
https://www.pinterest.com/annaklevenhagen/gas-station-aesthetic/
https://drizly.com/liquor-night-shop/s3434
https://www.pinterest.com/bhowmiksreejita/police-detective-aesthetic/
https://en.wikipedia.org/wiki/Protest
https://www.pinterest.com/huntardian/night-aesthetic/
https://www.pinterest.com/pin/526710118918156353/
https://www.thebroad.org/visit/mirror-rooms
"""

image = dict()
image["scene0"] = "room.jpg"
image["scene1"] = "portal.jpg"
image["scene2"] = "box_opening.jpg"
image["scene3"] = "box_opening.jpg"
image["scene4"] = "portal.jpg"
image["scene5"] = "storefront.jpg"
image["scene6"] = "drinks1.jpg"
image["scene7"] = "drinks1.jpg"
image["scene8"] = "drinks1.jpg"
image["scene9"] = "police.png"
image["scene10"] = "gun.jpg"
image["scene11"] = "ground.jpg"
image["scene12"] = "ground.jpg"
image["scene13"] = "portal.jpg"
image["scene14"] = "police.png"
image["scene15"] = "inside_store.jpg"
image["scene16"] = "inside_store.jpg"
image["scene17"] = "officers.jpg"
image["scene18"] = "officers.jpg"
image["scene19"] = "officers.jpg"
image["scene20"] = "fires.png"
image["scene21"] = "portal.jpg"
image["scene22"] = "box_opening.jpg"
image["scene23"] = "portal.jpg"
image["scene24"] = "inside_store.jpg"
image["scene25"] = "inside_store2.jpg"
image["scene26"] = "inside_store2.jpg"
image["scene27"] = "portal.jpg"
image["scene28"] = "box_opening.jpg"
image["scene29"] = "room.jpg"
image["scene30"] = "black.jpg"