import images
import script
import arcade
import os

# Set up the window viewer dimensions.
screen_width = 600
screen_height = 600

# This makes it easy to find any files we need as long as they are stored.
# in the same folder
file_path = os.path.dirname(os.path.abspath(__file__))
os.chdir(file_path)

# Draws image and text for each scene.
def scene_setup(text, image, text_placement="top"):
    arcade.start_render()
    background = arcade.load_texture(image)
    arcade.draw_lrwh_rectangle_textured(
        0, 0, screen_width, screen_height, background)

    if text_placement == "top":
        arcade.draw_text(text, screen_width / 2, 480,
                         arcade.color.WHITE, font_size=12, anchor_x="center")
    if text_placement == "bottom":
        arcade.draw_text(text, screen_width / 2, 100,
                         arcade.color.WHITE, font_size=12, anchor_x="center")

# Create a class for each scene to be displayed.
class instructions_screen(arcade.View):

    def on_draw(self):
        scene_setup(script.text["instructions"], images.image["scene30"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_0 = scene0()
        self.window.show_view(scene_0)


class scene0(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene0'], images.image["scene0"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_1 = scene1()
        self.window.show_view(scene_1)


class scene1(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene1'], images.image["scene1"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_2 = scene2()
        self.window.show_view(scene_2)


class scene2(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene2'], images.image["scene2"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_3 = scene3()
        self.window.show_view(scene_3)


class scene3(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene3'], images.image["scene3"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_4 = scene4()
        self.window.show_view(scene_4)


class scene4(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene4'], images.image["scene4"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_5 = scene5()
        self.window.show_view(scene_5)


class scene5(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene5'], images.image["scene5"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_6 = scene6()
        self.window.show_view(scene_6)


class scene6(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene6'], images.image["scene6"])
        arcade.draw_text(
            "Use the up key to choose soda\nUse the down key to choose water",
            screen_width / 2,
            100,
            arcade.color.WHITE,
            font_size=12,
            anchor_x="center")

    def on_key_press(self, symbol, modifiers):
        if symbol == arcade.key.UP:
            scene_7 = scene7()
            self.window.show_view(scene_7)
        if symbol == arcade.key.DOWN:
            scene_8 = scene8()
            self.window.show_view(scene_8)


class scene7(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene7'], images.image["scene7"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_9 = scene9()
        self.window.show_view(scene_9)


class scene8(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene8'], images.image["scene8"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_9 = scene9()
        self.window.show_view(scene_9)


class scene9(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene9'], images.image["scene9"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_10 = scene10()
        self.window.show_view(scene_10)


class scene10(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene10'], images.image["scene10"])
        arcade.draw_text(
            "Use the up key to defend yourself.\nUse the down key to comply with the officer",
            screen_width / 2,
            100,
            arcade.color.WHITE,
            font_size=12,
            anchor_x="center")

    def on_key_press(self, symbol, modifiers):
        if symbol == arcade.key.UP:
            scene_11 = scene11()
            self.window.show_view(scene_11)
        if symbol == arcade.key.DOWN:
            scene_12 = scene12()
            self.window.show_view(scene_12)


class scene11(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene11'], images.image["scene11"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_13 = scene13()
        self.window.show_view(scene_13)


class scene12(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene12'], images.image["scene12"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_13 = scene13()
        self.window.show_view(scene_13)


class scene13(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene13'], images.image["scene13"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_14 = scene14()
        self.window.show_view(scene_14)


class scene14(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene14'], images.image["scene14"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_15 = scene15()
        self.window.show_view(scene_15)


class scene15(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene15'], images.image["scene15"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_16 = scene16()
        self.window.show_view(scene_16)


class scene16(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene16'], images.image["scene16"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_17 = scene17()
        self.window.show_view(scene_17)


class scene17(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene17'], images.image["scene17"])
        arcade.draw_text(
            "Use the up key to choose intervene\nUse the down key to do nothing",
            screen_width / 2,
            100,
            arcade.color.WHITE,
            font_size=12,
            anchor_x="center")

    def on_key_press(self, symbol, modifiers):
        if symbol == arcade.key.UP:
            scene_18 = scene18()
            self.window.show_view(scene_18)
        if symbol == arcade.key.DOWN:
            scene_19 = scene19()
            self.window.show_view(scene_19)


class scene19(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene19'], images.image["scene19"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_20 = scene20()
        self.window.show_view(scene_20)


class scene20(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene20'], images.image["scene20"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_13 = scene13()
        self.window.show_view(scene_13)


class scene18(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene18'], images.image["scene18"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_21 = scene21()
        self.window.show_view(scene_21)


class scene21(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene21'], images.image["scene21"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_22 = scene22()
        self.window.show_view(scene_22)


class scene22(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene22'], images.image["scene22"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_23 = scene23()
        self.window.show_view(scene_23)


class scene23(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene23'], images.image["scene23"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_24 = scene24()
        self.window.show_view(scene_24)


class scene24(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene24'], images.image["scene24"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_25 = scene25()
        self.window.show_view(scene_25)


class scene25(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene25'], images.image["scene25"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_26 = scene26()
        self.window.show_view(scene_26)


class scene26(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene26'], images.image["scene26"], "bottom")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_27 = scene27()
        self.window.show_view(scene_27)


class scene27(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene27'], images.image["scene27"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_28 = scene28()
        self.window.show_view(scene_28)


class scene28(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene28'], images.image["scene28"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_29 = scene29()
        self.window.show_view(scene_29)


class scene29(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene29'], images.image["scene29"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        scene_30 = scene30()
        self.window.show_view(scene_30)


class scene30(arcade.View):

    def on_draw(self):
        scene_setup(script.text['scene30'], images.image["scene30"])

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        first_screen = instructions_screen()
        self.window.show_view(first_screen)

# Runs the program. 
def main():
    window = arcade.Window(screen_width, screen_height, "Story Game")
    first_screen = instructions_screen()
    window.show_view(first_screen)
    arcade.run()


if __name__ == "__main__":
    main()
